<?php if(session('success')): ?>
<div class="alert alert-success auto-hide">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="alert alert-danger auto-hide">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\hnoww_laravel\resources\views/admin/includes/messages.blade.php ENDPATH**/ ?>