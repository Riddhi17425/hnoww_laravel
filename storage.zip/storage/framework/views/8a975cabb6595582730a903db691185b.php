<?php echo $__env->make('layouts.frontheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
.theme-green .header-scrolled {
    background: #EDEAE4;
}

.theme-green .language-select .dropdown-input-lan {
    color: #0e2233;
}

@media (max-width:767px) {
    .sticky-header {
        /*background: #EDEAE4;*/
    }
}
</style>

<section class="mt_60">
    <div class="container">
        <div class="row">
            <div class="col-lg-7">
                <div class="pro_details">
                    <div class="left nav flex-column" id="productTab" role="tablist">
                        <?php if(isset($productDetailImages) && $productDetailImages != ''): ?>
                        <?php $__currentLoopData = $productDetailImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button class="nav-link <?php if($key == 0): ?> active <?php endif; ?>" data-bs-toggle="tab"
                            data-bs-target="#img1_<?php echo e($key); ?>"> 
                            <?php
                                $imagePath = public_path('images/admin/gifts/product_detail/' . $val);
                            ?>
                            <?php if(isset($val) && $val != '' && file_exists($imagePath)): ?>
                                <img src="<?php echo e(asset('public/images/admin/gifts/product_detail/'.$val)); ?>" alt="Sample Product">
                            <?php else: ?>
                                <img class="img-fluid" src="<?php echo e(asset('public/noimg.jpg')); ?>" alt="no image found">
                            <?php endif; ?>
                        </button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>

                    <div class="tab-content">
                        <?php if(isset($productDetailImages) && $productDetailImages != ''): ?>
                        <?php $__currentLoopData = $productDetailImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="tab-pane fade show <?php if($key == 0): ?> active <?php endif; ?>" id="img1_<?php echo e($key); ?>">
                            <div class="zoom-container">
                                <?php
                                    $imagePath = public_path('images/admin/gifts/product_detail/' . $val);
                                ?>
                                <?php if(isset($val) && $val != '' && file_exists($imagePath)): ?>
                                    <img class="zoom-image img-fluid" src="<?php echo e(asset('public/images/admin/gifts/product_detail/'.$val)); ?>" alt="Gift Product Detail Image">
                                <?php else: ?>
                                    <img class="img-fluid" src="<?php echo e(asset('public/noimg.jpg')); ?>" alt="no image found">
                                <?php endif; ?>
                                <div class="zoom-lens"></div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
            <div class="col-lg-5">
                <div class="pro_details_right">
                    <h2 class="main_head"><?php echo e($product->product_name ?? ''); ?></h2>
                    <p class="sub_head_inter para"><?php echo $product->short_description ?? ''; ?></p>
                    <h4 class="sub_head_inter">AED <?php echo e($product->product_price ?? ''); ?></h4>

                    <div class="increment_decrement_area">
                        <div class="increment_decrement">
                            <a href="#" class="com_btn" data-bs-toggle="modal" data-bs-target="#productInquiry">Enquire
                                Now </a>
                        </div>
                    </div>

                    <?php if(isset($product->large_description) && $product->large_description != ''): ?>
                    <h4 class="sub_head mb-4">The Story</h4>
                    <div class="mb-4">
                        <?php echo $product->large_description ?? ''; ?>

                    </div>
                    <?php endif; ?>
                    <?php if(isset($product->dimensions) && $product->dimensions != ''): ?>
                    <h4 class="sub_head mb-4">Material</h4>
                    <div class="pro_details_info_list">
                        <?php echo $product->dimensions ?? ''; ?>

                    </div>
                    <?php endif; ?>

                    
                </div>
            </div>
        </div>
</section>

<?php if(isset($productTab) && is_countable($productTab) && count($productTab) > 0): ?>
<section class="mt_60 mb-5">
    <div class="container">
        <div class="modern-tabs">
            <ul class="nav nav-tabs" id="filledTabs" role="tablist">
                <?php $__currentLoopData = $productTab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?php if($key == 0): ?> active <?php endif; ?>" 
                        id="tab-<?php echo e($key); ?>"  data-bs-toggle="tab"
                        data-bs-target="#tab-content-<?php echo e($key); ?>"  type="button" role="tab"
                        aria-controls="tab-content-<?php echo e($key); ?>" aria-selected="<?php if($key == 0): ?> true <?php else: ?> false <?php endif; ?>">
                        <?php echo e($val->title ?? ''); ?>

                    </button>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- TAB 2 -->
                

            </ul>

            <div class="tab-content" id="filledTabsContent">
                <?php $__currentLoopData = $productTab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade <?php if($key == 0): ?> show active <?php endif; ?>" 
                    id="tab-content-<?php echo e($key); ?>" role="tabpanel" aria-labelledby="tab-<?php echo e($key); ?>">
                    <?php echo $val->details ?? ''; ?>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<section class="mt_80 mb_120">
    <div class="container">
        <div class="section_header">
            <p class="sub_head mb-0">
                <span><svg width="63" height="6" viewBox="0 0 63 6" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M2.02656e-05 2.66669C2.02656e-05 4.13945 1.19393 5.33335 2.66669 5.33335C4.13945 5.33335 5.33335 4.13945 5.33335 2.66669C5.33335 1.19393 4.13945 2.02656e-05 2.66669 2.02656e-05C1.19393 2.02656e-05 2.02656e-05 1.19393 2.02656e-05 2.66669ZM2.66669 2.66669V3.16669H62.6667V2.66669V2.16669H2.66669V2.66669Z"
                            fill="#B58A46" />
                    </svg>
                </span>
                <span>Pairs</span>
                <span><svg width="63" height="6" viewBox="0 0 63 6" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M57.3333 2.66669C57.3333 4.13945 58.5272 5.33335 60 5.33335C61.4728 5.33335 62.6667 4.13945 62.6667 2.66669C62.6667 1.19393 61.4728 2.02656e-05 60 2.02656e-05C58.5272 2.02656e-05 57.3333 1.19393 57.3333 2.66669ZM0 2.66669V3.16669H60V2.66669V2.16669H0V2.66669Z"
                            fill="#B58A46" />
                    </svg>
                </span>
            </p>
            <h2 class="title_60">Similar Products</h2>
        </div>
        <div class="row gy-4 gy-md-0">
            <?php if(isset($similarProduct) && is_countable($similarProduct) && count($similarProduct) > 0): ?>
            <?php $__currentLoopData = $similarProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <a class="him_prod" href="<?php echo e(route('front.gift.details', $val->product_url)); ?>">
                    <div class="him_prod_top mb-2 mb-md-4">
                        <?php
                            $imagePath = public_path('images/admin/gifts/product_list/' . $val->list_page_img);
                        ?>
                        <?php if(isset($val->list_page_img) && $val->list_page_img != '' && file_exists($imagePath)): ?>
                            <img class="img-fluid img_1" src="<?php echo e(isset($val->list_page_img) ? asset('public/images/admin/gifts/product_list/'.$val->list_page_img) : ''); ?>"
                            alt="<?php echo e($val->product_name ?? 'Product Image'); ?>">
                        <?php else: ?>
                            <img class="img-fluid" src="<?php echo e(asset('public/noimg.jpg')); ?>" alt="no image found">
                        <?php endif; ?>
                    </div>
                    <div>
                        <div>
                            <h3 class="sub_head"><?php echo e($val->product_name ?? ''); ?></h3>
                            <p class="mb-0"><?php echo $val->short_description ?? ''; ?></p>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>

    </div>
</section>

<div class="modal fade audio_modal" id="productInquiry" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="productInquiryLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body">
                <div class="audio-card d-grid">
                    <div class="modal-header px-0">
                        <h5 class="modal-title" id="productInquiryLabel">Product Inquiry</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form method="POST" id="productInquiryForm" action="<?php echo e(route('front.store.product.inquiry')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" value="gift" name="inquiry_for">
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" name="name" value="<?php echo e(old('name')); ?>" placeholder="Enter Name"
                                oninput="this.value = this.value.replace(/[^a-zA-Z\s]/g, '').replace(/\s+/g, ' ').trimStart();"
                                class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <label class="form-label">Inquiry For Product</label>
                        <input type="text" class="form-control mb-3" value="<?php echo e($product->product_name ?? ''); ?>"
                            disabled>
                        <input type="hidden" name="product_id" value="<?php echo e($product->id ?? ''); ?>">
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" placeholder="Enter Your Email Address"
                                value="<?php echo e(old('email')); ?>" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Contact Number</label>
                            <input type="text" name="contact_no" placeholder="Enter your Whatsapp Phone Number"
                                value="<?php echo e(old('contact_no')); ?>"
                                oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 15);"
                                class="form-control <?php $__errorArgs = ['contact_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                            <?php $__errorArgs = ['contact_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Message</label>
                            <textarea name="message" rows="4" placeholder="Enter Message"
                                class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('message')); ?></textarea>
                            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="com_btn" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="com_btn">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('script'); ?>
<script>

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hnoww_laravel\resources\views/front/gift_details.blade.php ENDPATH**/ ?>