<div class="row">
<?php if($allGifts->isNotEmpty()): ?>
    <?php $__currentLoopData = $allGifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-4">
            <div class="gesture_box">
                <img class="img-fluid mb-2 mb-md-4"
                     src="<?php echo e(asset('public/images/admin/gifts/product_list/'.$val->list_page_img)); ?>">
                <div class="desire_box_bot_child">
                    <div>
                        <h3 class="sub_head"><?php echo e($val->product_name); ?></h3>
                        <p class="mb-0"><?php echo $val->short_description; ?></p>
                    </div>
                    <a href="<?php echo e(route('front.gift.details', $val->product_url)); ?>">
                            <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
                                <path d="M30.8334 9.16675L9.16669 30.8334M30.8334 9.16675H14.1667M30.8334 9.16675V25.8334"
                                    stroke="#8c8a72" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                        </a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <div class="col-12 text-center">
        <img src="<?php echo e(asset('public/images/product-not-found.png')); ?>" alt="Gifts not found">
    </div>
<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\hnoww_laravel\resources\views/front/partials/gift-list.blade.php ENDPATH**/ ?>