<?php echo $__env->make('layouts.frontheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
use Carbon\Carbon;
$currentMonthNumber = Carbon::now()->month;
$monthMap = [
'January' => 1,
'February' => 2,
'March' => 3,
'April' => 4,
'May' => 5,
'June' => 6,
'July' => 7,
'August' => 8,
'September' => 9,
'October' => 10,
'November' => 11,
'December' => 12,
];
?>
<!-- hero section -->
<section class="hero-section_inner">
    <img class="img-fluid" src="<?php echo e(asset('public/images/front/journal-banner.webp')); ?>" alt="journal banner">

    <div class="hero_content_inner">
        <h2 class="main_head mb-3">The Art of Hosting</h2>
        <p class="para mb-0">Hospitality is rarely about perfection. It is about the specific vibrations of a room when
            people feel one with the surroundings. It is the weight of a fork, the scent of unlit wax, and the way light
            catches the rim of a glass.</p>
    </div>
</section>
<section class="mt_60">
    <div class="container">
        <div class="month_box_main">
            <?php if(isset($journal) && is_countable($journal) && count($journal) > 0): ?>
            

        <?php $__currentLoopData = $journal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $journalMonthNumber = \Carbon\Carbon::createFromFormat('F', trim($val->month_name))->month;
        $monthName = trim($val->month_name);
        $journalMonthNumber = $monthMap[$monthName] ?? 0;
        ?>
        <div class="month_box">
            <h5 class="sub_head_inter"><?php echo e($val->month_name); ?></h5>
            <p><?php echo e($val->title); ?></p>
            <img src="<?php echo e(asset('public/images/admin/journal/thumbnail_images/'.$val->thumbnail_img)); ?>">
            <?php if($journalMonthNumber <= $currentMonthNumber): ?> <a href="#month-<?php echo e($journalMonthNumber); ?>">
                <svg class="green_svg" width="20" height="20" viewBox="0 0 20 20">
                    <path d="M19 1L1 19M19 1H5.15385M19 1V14.8462" stroke="#0D5E4C" stroke-width="2"
                        stroke-linecap="round" stroke-linejoin="round" />
                </svg>
                </a>
                <?php else: ?>
                <span>
                    <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M11.6667 18.3335V11.6666C11.6667 7.06428 15.3976 3.33331 20 3.33331C24.6023 3.33331 28.3333 7.06428 28.3333 11.6666V18.3335M8.33333 36.6668H31.6667C33.5077 36.6668 35 35.1743 35 33.3335V21.6668C35 19.8258 33.5077 18.3335 31.6667 18.3335H8.33333C6.49238 18.3335 5 19.8258 5 21.6668V33.3335C5 35.1743 6.49238 36.6668 8.33333 36.6668Z"
                            stroke="#C8B58D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                </span>
                <?php endif; ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
    </div>
</section>

<section class="mt_80 mb_120">
    <div class="container">
        <div class="section_header">
            <p class="sub_head mb-0">
                <span><svg width="63" height="6" viewBox="0 0 63 6" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M2.02656e-05 2.66669C2.02656e-05 4.13945 1.19393 5.33335 2.66669 5.33335C4.13945 5.33335 5.33335 4.13945 5.33335 2.66669C5.33335 1.19393 4.13945 2.02656e-05 2.66669 2.02656e-05C1.19393 2.02656e-05 2.02656e-05 1.19393 2.02656e-05 2.66669ZM2.66669 2.66669V3.16669H62.6667V2.66669V2.16669H2.66669V2.66669Z"
                            fill="#B58A46" />
                    </svg>
                </span>
                <span>the</span>
                <span><svg width="63" height="6" viewBox="0 0 63 6" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M57.3333 2.66669C57.3333 4.13945 58.5272 5.33335 60 5.33335C61.4728 5.33335 62.6667 4.13945 62.6667 2.66669C62.6667 1.19393 61.4728 2.02656e-05 60 2.02656e-05C58.5272 2.02656e-05 57.3333 1.19393 57.3333 2.66669ZM0 2.66669V3.16669H60V2.66669V2.16669H0V2.66669Z"
                            fill="#B58A46" />
                    </svg>
                </span>
            </p>
            <h2 class="title_60">2026 Editions</h2>
            <p>Publishing Schedule</p>
        </div>

        <div class="row g-4 g-xxl-5">
            <?php if(isset($journal) && is_countable($journal) && count($journal) > 0): ?>
            
    <?php $__currentLoopData = $journal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
    $journalMonthNumber = Carbon::parse($val->month_name)->month;
    $journalMonthNumber = \Carbon\Carbon::createFromFormat('F', trim($val->month_name))->month;
    $monthName = trim($val->month_name);
    $journalMonthNumber = $monthMap[$monthName] ?? 0;
    ?>

    <?php if($journalMonthNumber <= $currentMonthNumber): ?> <div class="col-md-6" id="month-<?php echo e($journalMonthNumber); ?>">
        <div class="row gy-3 gy-lg-0">
            <div class="col-lg-6">
                <div class="montheditions_lt">
                    <img class="img-fluid"
                        src="<?php echo e(asset('public/images/admin/journal/detail_images/'.$val->detail_img)); ?>">

                    <a class="com_btn"> 
                        <span class="ms-2"><?php echo e($val->month_name); ?></span>
                    </a>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="montheditions_rt">
                    <h3 class="sub_head mb-md-3"><?php echo e($val->title); ?></h3>
                    <?php if(isset($val->feature_title)): ?><p class="montheditions_para">Feature: <?php echo e($val->feature_title); ?></p>
                    <?php endif; ?>
                    <?php if(isset($val->feature_description)): ?><p><?php echo e($val->feature_description ?? ''); ?></p><?php endif; ?>

                    <div class="content-wrap">
                        <h3 class="sub_head mt-md-4 mb-md-3">The Practice:</h3>
                        <!--<p class="montheditions_para">Teach readers to curate a reflective moment � candles, scent, a silver bowl, a note of intention.</p>
                                        <p class="sub_head_inter mb-0">Ritual as self-care through design..</p> -->
                        <?php echo $val->description; ?>

                    </div>
                    <a href="javascript:void(0)" class="read-more-btn">Read More</a>

                </div>
            </div>


        </div>
        </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endif; ?>
        </div>
        </div>
        </div>
</section>


<script>
    document.querySelectorAll(".read-more-btn").forEach((btn) => {
    btn.addEventListener("click", function () {
        const wrapper = this.previousElementSibling;

        if (!wrapper.classList.contains("expanded")) {
            // OPEN
            wrapper.style.maxHeight = wrapper.scrollHeight + "px";
            wrapper.classList.add("expanded");
            this.textContent = "Read Less";
        } else {
            // CLOSE
            wrapper.style.maxHeight = wrapper.scrollHeight + "px"; 
            requestAnimationFrame(() => {
                wrapper.style.maxHeight = "90px";
            });
            wrapper.classList.remove("expanded");
            this.textContent = "Read More";
        }
    });
});
</script>

<?php echo $__env->make('layouts.frontfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hnoww_laravel\resources\views/front/journal.blade.php ENDPATH**/ ?>