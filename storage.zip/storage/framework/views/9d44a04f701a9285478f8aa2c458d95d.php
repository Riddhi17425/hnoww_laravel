<?php echo $__env->make('layouts.frontheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="hero-section_inner">
    <img class="img-fluid" src="<?php echo e(asset('public/images/front/frequently-asked-banner.webp')); ?>" alt="him banner">
    <div class="hero_content_inner">
        <h2 class="main_head mb-3">Questions…Answered With Care And Clarity
</h2>
        <p class="para sec_in_mb">Everything you need to know about our objects, ordering pathways, and processes, guided with clarity, discretion, and care.
</p>
    </div>
</section>

<?php if(isset($faq) && is_countable($faq) && count($faq) > 0): ?>
<section class="mt_60 mb_120">
    <div class="container">
        <div class="modern-tabs faq_cont">
            <ul class="nav nav-tabs" id="filledTabs" role="tablist">
                <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?php if($key == 0): ?> active <?php endif; ?>" id="tab-<?php echo e($key); ?>" data-bs-toggle="tab"
                        data-bs-target="#tab-content-<?php echo e($key); ?>" type="button" role="tab"
                        aria-controls="tab-content-<?php echo e($key); ?>" aria-selected="<?php echo e($key == 0 ? 'true' : 'false'); ?>">
                        <?php echo e($val->name ?? '-'); ?>

                    </button>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            <div class="tab-content border-0" id="filledTabsContent">
                <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade <?php if($key == 0): ?> show active <?php endif; ?>" id="tab-content-<?php echo e($key); ?>" role="tabpanel"
                    aria-labelledby="tab-<?php echo e($key); ?>">

                    <div class="accordion" id="accordion-<?php echo e($key); ?>">
                        <?php $__currentLoopData = $val->faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fkey => $fval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="faq_cont_acco">
                            <h2 class="according_head sub_head" data-bs-toggle="collapse"
                                data-bs-target="#collapse-<?php echo e($key); ?>-<?php echo e($fkey); ?>" aria-expanded="false"
                                aria-controls="collapse-<?php echo e($key); ?>-<?php echo e($fkey); ?>">
                                <?php echo e($fval->question ?? '-'); ?>

                            </h2>
                            <div id="collapse-<?php echo e($key); ?>-<?php echo e($fkey); ?>" class="accordion-collapse collapse"
                                data-bs-parent="#accordion-<?php echo e($key); ?>">
                                <div class="accordion-body">
                                    <?php echo $fval->answer ?? '-'; ?>

                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>


<?php echo $__env->make('layouts.frontfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hnoww_laravel\resources\views/front/faqs.blade.php ENDPATH**/ ?>