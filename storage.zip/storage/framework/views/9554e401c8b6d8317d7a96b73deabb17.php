<?php echo $__env->make('layouts.frontheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<!-- hero section -->
<section class="hero-section_inner">
    <img class="img-fluid" src="<?php echo e(asset('public/images/front/corporate-vault-banner.webp')); ?>" alt="him banner">

    <div class="hero_content_inner">
        <h2 class="main_head">The Corporate Vault</h2>
        <p class="para my-3">Objects designed to remain.</p>
        <a href="#" class="com_btn bg-white border-0" data-bs-toggle="modal"
            data-bs-target="#requestCorporateProposal">Request CORPORATE CATALOGUE</a>
    </div>
</section>

<section class="mt_60 request_catalogue_para">
    <div class="container">
        <p class="text-center sub_head_inter" style="color:#666666">A considered collection of architectural desk
            objects, ritual instruments, and enduring artefacts curated for leadership environments.
            Each object in the Corporate Vault is selected for <b>material integrity, discretion,</b> and its ability to
            <b>remain
                appropriate over time.</b>
        </p>

        <p class="text-center sub_head_inter" style="color:#666666">This is not gifting for the moment. This is
            representation, chosen carefully.</p>
    </div>
</section>


<?php if(isset($categories) && is_countable($categories) && count($categories) > 0): ?>

<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(isset($v->products) && is_countable($v->products) && count($v->products) > 0): ?>
<section class="mt_120 mb_120">
    <div class="container">
        <div class="section_header">
            <p class="sub_head mb-0">
                <span><svg width="63" height="6" viewBox="0 0 63 6" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M2.02656e-05 2.66669C2.02656e-05 4.13945 1.19393 5.33335 2.66669 5.33335C4.13945 5.33335 5.33335 4.13945 5.33335 2.66669C5.33335 1.19393 4.13945 2.02656e-05 2.66669 2.02656e-05C1.19393 2.02656e-05 2.02656e-05 1.19393 2.02656e-05 2.66669ZM2.66669 2.66669V3.16669H62.6667V2.66669V2.16669H2.66669V2.66669Z"
                            fill="#B58A46" />
                    </svg>
                </span>
                <span>Collections</span>
                <span><svg width="63" height="6" viewBox="0 0 63 6" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M57.3333 2.66669C57.3333 4.13945 58.5272 5.33335 60 5.33335C61.4728 5.33335 62.6667 4.13945 62.6667 2.66669C62.6667 1.19393 61.4728 2.02656e-05 60 2.02656e-05C58.5272 2.02656e-05 57.3333 1.19393 57.3333 2.66669ZM0 2.66669V3.16669H60V2.66669V2.16669H0V2.66669Z"
                            fill="#B58A46" />
                    </svg>
                </span>
            </p>
            <h2 class="title_60"><?php echo e($v->category_name ?? ''); ?></h2>
            <p><?php echo $v->description ?? ''; ?></p>
            <a href="#" class="com_btn" data-bs-toggle="modal" data-category="<?php echo e($v->id); ?>" data-bs-target="#requestCorporateProduct"><?php echo e($v->button_text ?? ''); ?></a>
        </div>

        <div class="row gy-4 gy-lg-0">
            <?php if(isset($v->products) && is_countable($v->products) && count($v->products) > 0): ?>
            <?php $__currentLoopData = $v->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(($k == 0 || $k == 1) && $key == 3): ?>
            <?php break; ?>
            
            <?php endif; ?>
            <div class="col-md-4">
                <div class="desire_box">
                    <img class="w-100 mb-2 mb-md-4"
                        src="<?php echo e(asset('public/images/admin/product_list/'.$val->list_page_img)); ?>" alt="images">
                    <div class="desire_box_bot_child">
                        <div>
                            <h3 class="sub_head"><?php echo e($val->product_name ?? ''); ?></h3>
                            <p class="mb-0"><?php echo $val->short_description ?? ''; ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <?php if($k == 2 && $key == 1): ?>
            <div class="col-md-4">
                <div class="desire_box">
                    <div class="hospitality_img">
                        
                        <img class="w-100 mb-2 mb-md-4" src="<?php echo e(asset('public/images/front/hospitality3.webp')); ?>" alt="images">
                        <div class="hospitality_img_overlay">
                            <h3 class="title_36">These objects are not decorative.
                                <p></p>
                                They are intended to <b>mark moments without diminishing them.</b>
                            </h3>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php if($k == 3 && $key == 1): ?>
            <div class="col-md-4">
                <div class="desire_box">
                    <div class="hospitality_img">
                        <img class="w-100 mb-2 mb-md-4" src="<?php echo e(asset('public/images/front/hospitality3.webp')); ?>"
                            alt="images">
                        <div class="hospitality_img_overlay">
                            <h3 class="title_36">These pieces respect Gulf traditions of <b>karam, </b> interpreted for
                                contemporary spaces.</h3>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            
    </div>
    </div>
</section>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?>

<section class="about">
    <div class="container">
        <div class="magic_wrapper pt-0 pb-lg-4" style="">
            <!--<h2 class="magic_head_phone">-->
            <!--    Containment & Presentation-->
            <!--</h2>-->
            <!-- 3️⃣ Left image (from left) -->
            <div class="text-lg-end ">
                <img src="<?php echo e(asset('public/images/front/home_magic_left.svg')); ?>" loading="lazy" alt=""
                    class="img-fluid">
            </div>

            <!-- 2️⃣ Center image (scale 0 → 1) -->
            <div class="magic_wrapper_center">
                <img src="<?php echo e(asset('public/images/front/home_magic.webp')); ?>" loading="lazy" alt="" class="img-fluid">
                <p class="magic_wrapper_p"> For how an object arrives.</p>
            </div>

            <!-- 4️⃣ Text block (from right) -->
            <div>
                 <h2 class="magic_head_1 position-static d-block">
                Containment
            </h2>
                <p>
                    Every piece in the Corporate Vault is presented in <b>signature velvet boxes,</b> designed for
                    permanence , not transit.
                </p>
                <p>No flimsy cartons. <br> No disposable packaging.</p>
                <p>The container signals the same care as the object.</p>
            </div>

            <!-- 1️⃣ First heading (from right) -->
            <!--<h2 class="magic_head_1">-->
            <!--    Containment &-->
            <!--</h2>-->

            <!-- 5️⃣ Last heading (from right) -->
            <!--<h2 class="magic_head_2">-->
            <!--    Presentation-->
            <!--</h2>-->

        </div>
    </div>
</section>
<?php if(isset($corporateKits) && count($corporateKits) && count($corporateKits) > 0): ?>

<section class="mt_35">
    <div class="container">
        <div class="section_header">
            <p class="sub_head mb-0">
                <span><svg width="63" height="6" viewBox="0 0 63 6" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M2.02656e-05 2.66669C2.02656e-05 4.13945 1.19393 5.33335 2.66669 5.33335C4.13945 5.33335 5.33335 4.13945 5.33335 2.66669C5.33335 1.19393 4.13945 2.02656e-05 2.66669 2.02656e-05C1.19393 2.02656e-05 2.02656e-05 1.19393 2.02656e-05 2.66669ZM2.66669 2.66669V3.16669H62.6667V2.66669V2.16669H2.66669V2.66669Z"
                            fill="#B58A46" />
                    </svg>
                </span>
                <span>CURATED</span>
                <span><svg width="63" height="6" viewBox="0 0 63 6" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M57.3333 2.66669C57.3333 4.13945 58.5272 5.33335 60 5.33335C61.4728 5.33335 62.6667 4.13945 62.6667 2.66669C62.6667 1.19393 61.4728 2.02656e-05 60 2.02656e-05C58.5272 2.02656e-05 57.3333 1.19393 57.3333 2.66669ZM0 2.66669V3.16669H60V2.66669V2.16669H0V2.66669Z"
                            fill="#B58A46" />
                    </svg>
                </span>
            </p>
            <h2 class="title_60">Corporate Kits</h2>
            <p>Pre-designed ensembles for specific corporate milestones.</p>
        </div>

        <div class="cor_kits_slider">
            <?php $__currentLoopData = $corporateKits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="cor_kts">
                        <img  class="img-fluid d-none d-md-block cor_kits_slider_img" src="<?php echo e(asset('public/images/admin/corporatekit/'.$val->image)); ?>" alt="">
                        <img  class="img-fluid d-md-none" src="<?php echo e(asset('public/images/admin/corporatekit/mobile_image/'.$val->mobile_image)); ?>" alt="">

                <div class="cor_kits_cont">
                    <div>
                        <h3 class="title_40"><?php echo e($val->title ?? ''); ?></h3>
                        <p><?php echo $val->short_description; ?></p>
                    </div>
                    <div class="sub_head my-4">
                        <p><?php echo $val->large_description; ?></p>
                        
                    </div>

                    
                    <a href="#" class="com_btn border-white" data-bs-toggle="modal"
                        data-bs-target="#requestCorporateKitProposal">Request CORPORATE CATALOGUE</a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            

    </div>
    </div>
</section>
<?php endif; ?>

<section class="mt_120">
    <div class="container">
        <div class="section_header">
            <h2 class="title_60">Customization & Recognition</h2>
        </div>
        <div class="text-center">
            <p>All Corporate Vault objects support understated customisation designed to remain appropriate.</p>
            <h4 class="sub_head" style="color:var(--secondary-color); font-style: italic;">This includes:</h4>
            <p>Company-led recognition cards | Internal branding only (never front-facing)</p>
            <p>Customisation is treated as <b>representation,</b> not promotion.</p>
        </div>
    </div>
</section>

<section class="mt_120 mb_120">
    <div class="container">
        <div class="section_header">
            <p class="sub_head mb-0">
                <span><svg width="63" height="6" viewBox="0 0 63 6" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M2.02656e-05 2.66669C2.02656e-05 4.13945 1.19393 5.33335 2.66669 5.33335C4.13945 5.33335 5.33335 4.13945 5.33335 2.66669C5.33335 1.19393 4.13945 2.02656e-05 2.66669 2.02656e-05C1.19393 2.02656e-05 2.02656e-05 1.19393 2.02656e-05 2.66669ZM2.66669 2.66669V3.16669H62.6667V2.66669V2.16669H2.66669V2.66669Z"
                            fill="#B58A46" />
                    </svg>
                </span>
                <span>the</span>
                <span><svg width="63" height="6" viewBox="0 0 63 6" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M57.3333 2.66669C57.3333 4.13945 58.5272 5.33335 60 5.33335C61.4728 5.33335 62.6667 4.13945 62.6667 2.66669C62.6667 1.19393 61.4728 2.02656e-05 60 2.02656e-05C58.5272 2.02656e-05 57.3333 1.19393 57.3333 2.66669ZM0 2.66669V3.16669H60V2.66669V2.16669H0V2.66669Z"
                            fill="#B58A46" />
                    </svg>
                </span>
            </p>
            <h2 class="title_60">Trust Builders</h2>
        </div>
        <div class="row gy-4 gy-lg-0">
            <div class="col-md-4">
                <div class="collection_box">
                    <img class="img-fluid mb-4" src="<?php echo e(asset('public/images/front/builder1.webp')); ?>" alt="images"
                        loading="lazy">
                    <h3 class="sub_head">The Recognition Standard</h3>
                    <p><b>Representation begins with recognition.</b> Each gift carries a company-led message.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="collection_box">
                    <img class="img-fluid mb-4" src="<?php echo e(asset('public/images/front/builder2.webp')); ?>" alt="images"
                        loading="lazy">
                    <h3 class="sub_head">The Packaging Standard</h3>
                    <p>Every object arrives contained in our signature velvet boxes, designed for permanence.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="collection_box">
                    <img class="img-fluid mb-4" src="<?php echo e(asset('public/images/front/builder3.webp')); ?>" alt="images"
                        loading="lazy">
                    <h3 class="sub_head">The Lead Time</h3>
                    <p>"Production: <b>30-45 Days.</b> " Rush orders available upon request.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Corporate Product -->
<div class="modal fade corporate_vault_modal" id="requestCorporateProduct" data-bs-backdrop="static"
    data-bs-keyboard="false" tabindex="-1" aria-labelledby="requestCorporateKitProposalLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-body">
                <div class="container">
                    <div class="text-center my-4">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form method="POST" action="<?php echo e(route('front.store.corporate.product.request')); ?>" id="requestCorporateProductForm" class="ct_form">
                        <?php echo csrf_field(); ?>
                        
                        <div class="row">
                            <!-- Full Name -->
                            <div class="col-lg-6">
                                <div class="ct_input">
                                    <label class="sub_head">Full Name <span class="text-danger">*</span></label>
                                    <input type="text" name="cp_full_name" id="cp_full_name"
                                        oninput="this.value = this.value.replace(/[^a-zA-Z\s]/g, '').replace(/\s+/g, ' ').trimStart();"
                                        placeholder="Enter your Full Name" value="<?php echo e(old('cp_full_name')); ?>">
                                    <?php $__errorArgs = ['cp_full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Company -->
                            <div class="col-lg-6">
                                <div class="ct_input">
                                    <label class="sub_head">Company Organization <span
                                            class="text-danger">*</span></label>
                                    <input type="text" name="cp_company_name"
                                        placeholder="Enter your Company Organization Name" id="cp_company_name"
                                        value="<?php echo e(old('cp_company_name')); ?>">
                                    <?php $__errorArgs = ['cp_company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Phone -->
                            <div class="col-lg-6">
                                <div class="ct_input">
                                    <label class="sub_head">Phone Number <span class="text-danger">*</span></label>
                                    <input type="text" name="cp_phone" id="cp_phone"
                                        placeholder="Enter your WhatsApp Phone Number"
                                        oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 15);"
                                        value="<?php echo e(old('phone')); ?>">
                                    <?php $__errorArgs = ['cp_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Email -->
                            <div class="col-lg-6">
                                <div class="ct_input">
                                    <label class="sub_head">Email <span class="text-danger">*</span></label>
                                    <input type="email" name="cp_email" placeholder="Enter your Email Address"
                                        id="cp_email" value="<?php echo e(old('cp_email')); ?>">
                                    <?php $__errorArgs = ['cp_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Product of Interest (MULTISELECT) -->
                            <div class="col-lg-4">
                                <div class="ct_input">
                                    <label class="sub_head">Product of Interest <span
                                            class="text-danger">*</span></label>
                                    <select id="cp_product_of_interest" name="cp_product_of_interest[]" multiple>
                                        <?php if(isset($corporateKits) && is_countable($corporateKits) &&
                                        count($corporateKits) > 0): ?>
                                        <?php $__currentLoopData = $corporateKits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value->id); ?>"
                                            <?php echo e(collect(old('cp_product_of_interest'))->contains($value->id) ? 'selected' : ''); ?>>
                                            <?php echo e($value->title); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                    <div id="c_product_kit_error"></div>
                                    <?php $__errorArgs = ['cp_product_of_interest'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Quantity Range -->
                            <div class="col-lg-4">
                                <div class="ct_input">
                                    <label class="sub_head">Quantity Range <span class="text-danger">*</span></label>
                                    <select name="cp_quantity_range" id="cp_quantity_range">
                                        <option value="">Select</option>
                                        <?php $__currentLoopData = config('global_values.quality_range'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>"
                                            <?php echo e(old('cp_quantity_range') == $key ? 'selected' : ''); ?>>
                                            <?php echo e($value); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['cp_quantity_range'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Budget -->
                            <div class="col-lg-4">
                                <div class="ct_input">
                                    <label class="sub_head">Approximate Budget</label>
                                    <select name="cp_corporate_budget" id="cp_corporate_budget">
                                        <option value="">Select</option>
                                        <?php $__currentLoopData = config('global_values.corporate_budget'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php echo e(old('cp_corporate_budget') == $key ? 'selected' : ''); ?>>
                                            <?php echo e($value); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['cp_corporate_budget'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Branding -->
                            <div class="col-lg-6">
                                <div class="ct_input">
                                    <label class="sub_head">Branding Requirements</label>
                                    <input type="text" placeholder="e.g. Logo etching, Custom box colour"
                                        name="cp_branding_requirements" id="cp_branding_requirements"
                                        value="<?php echo e(old('cp_branding_requirements')); ?>">
                                </div>
                            </div>

                            <!-- Delivery Date -->
                            <div class="col-lg-6">
                                <div class="ct_input">
                                    <label class="sub_head">Delivery Timeline <span class="text-danger">*</span></label>
                                    <select name="cp_delivery_date" id="cp_delivery_date">
                                        <option value="">Select</option>
                                        <?php $__currentLoopData = config('global_values.corporate_timeline'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php echo e(old('cp_delivery_date') == $key ? 'selected' : ''); ?>>
                                            <?php echo e($value); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['cp_delivery_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Message -->
                            <div class="col-12">
                                <div class="ct_input">
                                    <label class="sub_head">Message / Notes</label>
                                    <textarea name="cp_message" placeholder="Enter Message" id="cp_message" rows="1"><?php echo e(old('cp_message')); ?></textarea>
                                </div>
                            </div>

                            <div class="col-12 text-center">
                                <button type="submit" class="com_btn bg-transparent">ENQUIRE NOW</button>
                            </div>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Corporate Kit Request -->
<div class="modal fade corporate_vault_modal" id="requestCorporateKitProposal" data-bs-backdrop="static"
    data-bs-keyboard="false" tabindex="-1" aria-labelledby="requestCorporateKitProposalLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-body">
                <div class="container">
                    <div class="text-center my-4">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form method="POST" action="<?php echo e(route('front.store.corporate.kit.request')); ?>"
                        id="requestCorporateKitProposalForm" class="ct_form">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <!-- Full Name -->
                            <div class="col-lg-6">
                                <div class="ct_input">
                                    <label class="sub_head">Full Name <span class="text-danger">*</span></label>
                                    <input type="text" name="k_full_name" id="k_full_name"
                                        oninput="this.value = this.value.replace(/[^a-zA-Z\s]/g, '').replace(/\s+/g, ' ').trimStart();"
                                        placeholder="Enter your Full Name" value="<?php echo e(old('k_full_name')); ?>">
                                    <?php $__errorArgs = ['k_full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Company -->
                            <div class="col-lg-6">
                                <div class="ct_input">
                                    <label class="sub_head">Company Organization <span
                                            class="text-danger">*</span></label>
                                    <input type="text" name="k_company_name"
                                        placeholder="Enter your Company Organization Name" id="k_company_name"
                                        value="<?php echo e(old('k_company_name')); ?>">
                                    <?php $__errorArgs = ['k_company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Phone -->
                            <div class="col-lg-6">
                                <div class="ct_input">
                                    <label class="sub_head">Phone Number <span class="text-danger">*</span></label>
                                    <input type="text" name="k_phone" id="k_phone"
                                        placeholder="Enter your WhatsApp Phone Number"
                                        oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 15);"
                                        value="<?php echo e(old('phone')); ?>">
                                    <?php $__errorArgs = ['k_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Email -->
                            <div class="col-lg-6">
                                <div class="ct_input">
                                    <label class="sub_head">Email <span class="text-danger">*</span></label>
                                    <input type="email" name="k_email" placeholder="Enter your Email Address"
                                        id="k_email" value="<?php echo e(old('k_email')); ?>">
                                    <?php $__errorArgs = ['k_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Product of Interest (MULTISELECT) -->
                            <div class="col-lg-4">
                                <div class="ct_input">
                                    <label class="sub_head">Product of Interest <span
                                            class="text-danger">*</span></label>
                                    <select id="k_product_of_interest" name="k_product_of_interest[]" multiple>
                                        <?php if(isset($corporateKits) && is_countable($corporateKits) &&
                                        count($corporateKits) > 0): ?>
                                        <?php $__currentLoopData = $corporateKits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value->id); ?>"
                                            <?php echo e(collect(old('k_product_of_interest'))->contains($value->id) ? 'selected' : ''); ?>>
                                            <?php echo e($value->title); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                    <div id="product_kit_error"></div>
                                    <?php $__errorArgs = ['k_product_of_interest'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Quantity Range -->
                            <div class="col-lg-4">
                                <div class="ct_input">
                                    <label class="sub_head">Quantity Range <span class="text-danger">*</span></label>
                                    <select name="k_quantity_range" id="k_quantity_range">
                                        <option value="">Select</option>
                                        <?php $__currentLoopData = config('global_values.quality_range'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>"
                                            <?php echo e(old('k_quantity_range') == $key ? 'selected' : ''); ?>>
                                            <?php echo e($value); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['k_quantity_range'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Budget -->
                            <div class="col-lg-4">
                                <div class="ct_input">
                                    <label class="sub_head">Approximate Budget</label>
                                    <input type="text" placeholder="Enter Approximate Budget" name="k_budget"
                                        id="k_budget" value="<?php echo e(old('k_budget')); ?>">
                                    <?php $__errorArgs = ['k_budget'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Branding -->
                            <div class="col-lg-6">
                                <div class="ct_input">
                                    <label class="sub_head">Branding Requirements</label>
                                    <input type="text" placeholder="e.g. Logo etching, Custom box colour"
                                        name="k_branding_requirements" id="k_branding_requirements"
                                        value="<?php echo e(old('k_branding_requirements')); ?>">
                                </div>
                            </div>

                            <!-- Delivery Date -->
                            <div class="col-lg-6">
                                <div class="ct_input">
                                    <label class="sub_head">Delivery Timeline <span class="text-danger">*</span></label>
                                    <input type="date" name="k_delivery_date" id="k_delivery_date"
                                        value="<?php echo e(old('k_delivery_date')); ?>">
                                    <?php $__errorArgs = ['k_delivery_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Message -->
                            <div class="col-12">
                                <div class="ct_input">
                                    <label class="sub_head">Message / Notes</label>
                                    <textarea name="k_message" placeholder="Enter Message"
                                        id="k_message" rows="1"><?php echo e(old('k_message')); ?></textarea>
                                </div>
                            </div>

                            <div class="col-12 text-center">
                                <button type="submit" class="com_btn bg-transparent">REQUEST CORPORATE QUOTE</button>
                            </div>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function() {
        var cKFormSubmitted = false;
        var cFormSubmitted = false;
        var element = $('#k_product_of_interest')[0];  // get raw DOM element from jQuery object
        var choices = new Choices(element, {
            removeItemButton: true,  // shows an "x" to deselect each selected option
            placeholder: true,
            placeholderValue: 'Select products',
            searchEnabled: true,
        });
        $('#cp_product_of_interest').on('change', function () {
            $(this).valid();
        });

        var elementCp = $('#cp_product_of_interest')[0];  // get raw DOM element from jQuery object
        var choicesCp = new Choices(elementCp, {
            removeItemButton: true,  // shows an "x" to deselect each selected option
            placeholder: true,
            placeholderValue: 'Select products',
            searchEnabled: true,
        });

        // Before modal opens
        $('#requestCorporateProduct').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var categoryId = button.data('category');
            if (!categoryId) return;
            choicesCp.removeActiveItems();   // remove selected values
            choicesCp.clearChoices();        // remove old dropdown options
            $.ajax({
                url: sitePath + '/get-products-by-category/' + categoryId,
                type: 'GET',
                success: function (response) {
                    let newOptions = [];
                    response.forEach(function (product) {
                        newOptions.push({
                            value: product.id,
                            label: product.product_name
                        });
                    });
                    choicesCp.setChoices(newOptions, 'value', 'label', true);
                }
            });
        });

        $("#requestCorporateKitProposalForm").validate({
            ignore: [],
            rules: {
                k_full_name: {
                    required: true,
                    minlength: 2,
                    maxlength: 50,
                    lettersonly: true
                },
                k_company_name: {
                    required: true
                },
                k_phone: {
                    required: true,
                    number: true,
                    validPhone: true
                },
                k_email: {
                    required: true,
                    email: true,
                    noSpamEmail: true,
                    uniqueEmail: "corporate_kit_requests"
                },
                'k_product_of_interest[]': {
                    required: true
                },
                k_quantity_range: {
                    required: true
                },
                k_delivery_date: {
                    required: true,
                    date: true,
                    minDate: true
                },
                k_message: {
                    maxlength: 500,
                }
            },
            messages: {
                k_full_name: {
                    required: "Please enter your full name",
                    minlength: "Full name must be at least 2 characters",
                    maxlength: "Full name cannot exceed 50 characters",
                    lettersonly: "Full name can only contain letters and spaces"
                },
                k_company_name: {
                    required: "Please enter your company or organization name"
                },
                k_phone: {
                    required: "Please enter your phone number",
                    number: "Phone number must contain only digits",
                    validPhone: "Enter a valid phone number"
                },
                k_email: {
                    required: "Please enter your email address",
                    email: "Please enter a valid email address",
                    noSpamEmail: "This email address is not allowed",
                    uniqueEmail: "This email is already used"
                },
                'k_product_of_interest[]': {
                    required: "Please select at least one product of interest"
                },
                k_quantity_range: {
                    required: "Please select a quantity range"
                },
                k_delivery_date: {
                    required: "Please select a delivery date",
                    date: "Enter a valid date",
                    minDate: "Delivery date must be after today"
                },
                k_message: {
                    maxlength: "Message cannot exceed 50 characters",
                }
            },
            errorElement: 'div',
            errorPlacement: function(error, element) {
                if (element.attr('name') === 'k_product_of_interest[]') {
                    $('#product_kit_error').append(error);
                } else {
                    error.insertAfter(element);
                }
            },
            highlight: function(element) {
                $(element).addClass('is-invalid').removeClass('is-valid');
            },
            unhighlight: function(element) {
                $(element).addClass('is-valid').removeClass('is-invalid');
            },
            submitHandler: function(form) {
                if (!cKFormSubmitted) {
                    cKFormSubmitted = true;
                    const btn = $(form).find('button[type="submit"]');
                    if (btn.length) {
                        btn.prop('disabled', true).text('Submitting...');
                    }
                    form.submit();
                }
            }
        });

        $("#requestCorporateProductForm").validate({
            ignore: [],
            rules: { 
                cp_full_name: { 
                    required: true, 
                    minlength: 2, 
                    maxlength: 100, 
                    lettersonly: true 
                },
                cp_company_name: { 
                    required: true,
                    minlength: 2,
                    maxlength: 150
                },
                cp_phone:{
                    required: true,
                    number: true,
                    validPhone: true
                },
                cp_email: { 
                    required: true, 
                    email: true, 
                    noSpamEmail: true, 
                    uniqueEmail: "corporate_proposal_requests" 
                },
                'cp_product_of_interest[]': { 
                    required: true,
                },
                cp_quantity_range: { 
                    required: true 
                },
                cp_delivery_date: { 
                    required: true 
                },
                cp_message:{
                    maxlength: 500,
                }
            },
            messages: {
                cp_full_name: {
                    required: "Please enter your full name",
                    minlength: "Full name must be at least 2 characters",
                    maxlength: "Full name cannot exceed 100 characters",
                    lettersonly: "Full name can only contain letters and spaces"
                },
                cp_company_name: {
                    required: "Please enter your company or organization name",
                    minlength: "Company name must be at least 2 characters",
                    maxlength: "Company name cannot exceed 150 characters"
                },
                cp_email: {
                    required: "Please enter your email address",
                    email: "Please enter a valid email address",
                    noSpamEmail: "This email address is not allowed",
                    uniqueEmail: "This email is already used"
                },
                cp_phone: {
                    required: "Please enter your phone number",
                    number: "Phone number must contain only digits",
                    validPhone: "Enter a valid phone number"
                },
                'cp_product_of_interest[]': {
                    required: "Please select at least one product of interest",
                    minlength: "Please select at least one product of interest"
                },
                cp_quantity_range: {
                    required: "Please select a quantity range"
                },
                cp_delivery_date:{
                    required: "Please select a Delivery Date"
                },
                cp_message:{
                    maxlength: "Message cannot exceed 500 characters"
                }
            },
            errorElement: 'div',
            errorPlacement: function(error, element) {
                if (element.attr('name') === 'cp_product_of_interest[]') {
                    //$('#c_product_kit_error').append(error);
                    $('#c_product_kit_error').html('');
                    $('#c_product_kit_error').html(error);
                } else {
                    error.insertAfter(element);
                }
            },
            highlight: function(element) {
                $(element).addClass('is-invalid').removeClass('is-valid');
            },
            unhighlight: function(element) {
                $(element).addClass('is-valid').removeClass('is-invalid');
            },
            submitHandler: function(form) {
                if (!cFormSubmitted) {
                    cFormSubmitted = true;
                    const btn = $(form).find('button[type="submit"]');
                    if (btn.length) {
                        btn.prop('disabled', true).text('Submitting...');
                    }
                    form.submit();
                }
            }
        });

});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.frontfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hnoww_laravel\resources\views/front/corporate_vault.blade.php ENDPATH**/ ?>