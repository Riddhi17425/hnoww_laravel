<style>
/* Container check */
.form_check_main_modal {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
    margin-top: 20px;
}

/* Hidden Input */
.custom_check_input {
    display: none !important;
}

/* Base Label Style */
.custom_check_label {
    display: inline-block;
    padding: 10px 20px;
    border: 1px solid var(--gold-color) !important;
    border-radius: 50px;
    background-color: transparent;
    color: #666;
    cursor: pointer;
    transition: all 0.3s ease;
}

/* THE WORKING STATE */
/* Input check hone par Label ka style badlo */
.custom_check_input:checked+.custom_check_label {
    background-color: var(--gold-color) !important;
    color: white !important;
}
</style>

<!-- Corporate Request -->
<div class="modal fade corporate_vault_modal" id="requestCorporateProposal" data-bs-backdrop="static"
    data-bs-keyboard="false" tabindex="-1" aria-labelledby="requestCorporateProposalLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen modal-dialog-centered">
        <div class="modal-content">

            <div class="text-center my-4">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="container">

                    <div class="text-center mb-5">
                        <h4 class="title_60 mb-3" style="color: var(--dark-900)">Corporate Gifting Enquiry</h4>
                        <p class="sub_head_inter" style="font-family: var(--heading-font); font-style: italic;">
                            We work with organisations seeking meaningful, long-term gifting , <br> designed to be kept
                            rather
                            than
                            discarded.
                        </p>
                    </div>

                    <form method="POST" action="<?php echo e(route('front.store.corporate.proposal.request')); ?>"
                        id="requestCorporateProposalForm" class="ct_form">
                        <?php echo csrf_field(); ?>
                        <div class="row">

                            <!-- Full Name -->
                            <div class="col-lg-6">
                                <div class="ct_input">
                                    <label class="sub_head">Full Name <span class="text-danger">*</span></label>
                                    <input type="text" name="full_name" id="full_name"
                                        oninput="this.value = this.value.replace(/[^a-zA-Z\s]/g, '').replace(/\s+/g, ' ').trimStart();"
                                        placeholder="Enter your Full Name" value="<?php echo e(old('full_name')); ?>">
                                    <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Company -->
                            <div class="col-lg-6">
                                <div class="ct_input">
                                    <label class="sub_head">Company Name <span class="text-danger">*</span></label>
                                    <input type="text" name="company_name"
                                        placeholder="Enter your Company Organization Name" id="company_name"
                                        value="<?php echo e(old('company_name')); ?>">
                                    <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                             <!-- Email -->
                <div class="col-lg-6">
                    <div class="ct_input">
                        <label class="sub_head">Email <span class="text-danger">*</span></label>
                        <input type="email" name="email" placeholder="Enter your Email Address" id="email"
                            value="<?php echo e(old('email')); ?>">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                            <div class="col-lg-6">
                                <div class="ct_input">
                                    <label class="sub_head">Role / Designation <span
                                            class="text-danger">*</span></label>
                                    <input type="text" name="role" placeholder="Enter your Role" id="role"
                                        value="<?php echo e(old('role')); ?>">
                                    <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Phone -->
                            


                <!-- Product of Interest (MULTISELECT) -->
                

        <!-- Quantity Range -->
        <div class="col-lg-4">
            <div class="ct_input">
                <label class="sub_head">Quantity Range </label>
                <select name="quantity_range" id="quantity_range">
                    <option value="">Select</option>
                    <?php $__currentLoopData = config('global_values.quality_range'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>" <?php echo e(old('quantity_range') == $key ? 'selected' : ''); ?>>
                        <?php echo e($value); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['quantity_range'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="ct_input">
                <label class="sub_head">Budget Comfort (per unit) </label>
                <select name="corporate_budget" id="corporate_budget">
                    <option value="">Select</option>
                    <?php $__currentLoopData = config('global_values.corporate_budget'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>" <?php echo e(old('corporate_budget') == $key ? 'selected' : ''); ?>>
                        <?php echo e($value); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['corporate_budget'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="ct_input">
                <label class="sub_head">Timeline </label>
                <select name="timeline" id="timeline">
                    <option value="">Select</option>
                    <?php $__currentLoopData = config('global_values.corporate_timeline'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>" <?php echo e(old('timeline') == $key ? 'selected' : ''); ?>>
                        <?php echo e($value); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['timeline'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <!-- <div class="col-lg-12">
            <label class="form-label fw-bold d-block"> Nature of Requirement <span class="text-danger">*</span></label>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="ceremonial" name="nature_of_requirement[]"
                    value="Client / Partner Gifting">
                <label class="form-check-label" for="ceremonial">Client / Partner Gifting</label>
            </div>
            2
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="favours" name="nature_of_requirement[]"
                    value="Leadership / Board Gifts">
                <label class="form-check-label" for="favours">Leadership / Board Gifts</label>
            </div>
            3
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="legacy" name="nature_of_requirement[]"
                    value="Employee Recognition">
                <label class="form-check-label" for="legacy">Employee Recognition</label>
            </div>

            4
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="hampers" name="nature_of_requirement[]"
                    value="Milestone / Deal Closure">
                <label class="form-check-label" for="hampers">Milestone / Deal Closure</label>
            </div>

            5
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="unsure" name="nature_of_requirement[]"
                    value="Hospitality / Guest Experience">
                <label class="form-check-label" for="unsure"> Hospitality / Guest Experience</label>
            </div>
        </div> -->

        


        <!-- Budget -->
        

<!-- Branding -->


<!-- Delivery Date -->


<!-- Message -->
<div class="col-12">
    <div class="ct_input">
        <label class="sub_head">Message / Notes</label>
        <textarea name="message" placeholder="Enter Message" id="message" rows="1"><?php echo e(old('message')); ?></textarea>
    </div>
</div>

<div class="col-12 text-center">
    <button type="submit" class="com_btn bg-transparent">Submit Corporate Enquiry</button>
</div>

</div>
</form>
</div>
</div>

</div>
</div>
</div><?php /**PATH C:\xampp\htdocs\hnoww_laravel\resources\views/front/corporate_request_modal.blade.php ENDPATH**/ ?>