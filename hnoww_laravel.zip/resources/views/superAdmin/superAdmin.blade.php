@extends('layouts.app')

@section('content')
<h2 class="text-center">superAdmin page</h2>
@endsection