@extends('admin.layouts.app')

@section('title', 'Edit Journal')

@section('content')
<div class="container-xxl">
    <div class="row mb-3">
        <div class="col-md-6">
            <h3>Edit Journal</h3>
        </div>
        <div class="col-md-6 text-end">
            <a href="{{ route('admin.journals.index') }}" class="btn btn-secondary">Back</a>
        </div>
    </div>

    <form action="{{ route('admin.journals.update', $journal->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label">Month Name</label><span class="text-danger">*</span>
                <select name="month_name" class="form-control">
                    <option value="">-- Select Month --</option>
                    @foreach(config('global_values.months') as $month)
                        <option value="{{ $month }}"
                            {{ old('month_name', $journal->month_name ?? '') == $month ? 'selected' : '' }}>
                            {{ $month }}
                        </option>
                    @endforeach
                </select>
                @error('month_name') <span class="text-danger">{{ $message }}</span> @enderror
            </div>

            <div class="col-md-6">
                <label class="form-label">Title</label>
                <input type="text" name="title" class="form-control" value="{{ old('title', $journal->title) }}">
                @error('title') <span class="text-danger">{{ $message }}</span> @enderror
            </div>

            <div class="col-md-6">
                <label class="form-label">Feature Title</label><span class="text-danger">*</span>
                <input type="text" name="feature_title" class="form-control" value="{{ old('feature_title', $journal->feature_title) }}">
                @error('feature_title') <span class="text-danger">{{ $message }}</span> @enderror
            </div>

            <div class="col-md-6">
                <label class="form-label">Feature Description</label><span class="text-danger">*</span>
                <input type="text" name="feature_description" class="form-control" value="{{ old('feature_description', $journal->feature_description) }}">
                @error('feature_description') <span class="text-danger">{{ $message }}</span> @enderror
            </div>

            <div class="col-md-12">
                <label class="form-label">Description</label>
                <textarea name="description" id="description" class="form-control">{{ old('description', $journal->description) }}</textarea>
                @error('description') <span class="text-danger">{{ $message }}</span> @enderror
            </div>

            <div class="col-md-6">
                <label class="form-label">Thumbnail Image</label>
                @if($journal->thumbnail_img)
                    <div class="mb-2">
                        <img src="{{ asset('public/images/admin/journal/thumbnail_images/'.$journal->thumbnail_img) }}" width="100" alt="journal image">
                    </div>
                @endif
                <input type="file" name="thumbnail_img" class="form-control">
                @error('thumbnail_img') <span class="text-danger">{{ $message }}</span> @enderror
            </div>
            <div class="col-md-6">
                <label class="form-label">Detail Image</label>
                @if($journal->detail_img)
                    <div class="mb-2">
                        <img src="{{ asset('public/images/admin/journal/detail_images/'.$journal->detail_img) }}" width="100" alt="journal image">
                    </div>
                @endif
                <input type="file" name="detail_img" class="form-control">
                @error('detail_img') <span class="text-danger">{{ $message }}</span> @enderror
            </div>

            {{-- <div class="col-md-6">
                <label class="form-label">Sort Order</label>
                <input type="number" name="sort_by" class="form-control" value="{{ old('sort_by', $journal->sort_by) }}">
                @error('sort_by') <span class="text-danger">{{ $message }}</span> @enderror
            </div> --}}

            <div class="col-md-12">
                <button type="submit" class="btn btn-primary">Update Journal</button>
            </div>
        </div>
    </form>
</div>
@endsection
@push('custom_scripts')
<script src="{{ asset('public/js/admin/journal.js') }} " defer></script>
<script> 

$(document).ready(function() {
    $('#description').summernote({
        placeholder: 'Enter Description here...',
        height: 200,
        toolbar: [
            ['style', ['style']],
            ['font', ['bold', 'italic', 'underline', 'clear']],
            ['fontname', ['fontname']],
            ['color', ['color']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['height', ['height']],
            ['insert', ['link', 'picture', 'hr']],
            ['view', ['fullscreen', 'codeview']],
            ['help', ['help']]
        ]
    });
});
</script>

@endpush