@include('layouts.frontheader')
<!-- hero section -->
<section class="hero-section_inner">
    <img class="img-fluid" src="{{asset('public/images/front/bespoke-banner.png')}}" alt="him banner">

    <div class="hero_content_inner">
        <h2 class="main_head">Bespoke Wedding Hampers</h2>
        <p class="para">Curated gifting stories, presented in modern black H Noww boxes.</p>
    </div>
</section>

<section class="mt_60">
    <div class="container">
        <div class="row gy-4 gy-md-0">
            <div class="col-md-4">
                <div class="collection_box">
                    <img class="img-fluid mb-2 mb-md-4" src="{{asset('public/images/front/bespoke3.png')}}" alt="images">
                    <h3 class="sub_head">For Her — The Desert Rose</h3>
                    <p class="mb-0">Objects for hosting, memory, and grace</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="collection_box">
                    <img class="img-fluid mb-2 mb-md-4" src="{{asset('public/images/front/bespoke4.png')}}" alt="images">
                    <h3 class="sub_head">For Her — The Desert Rose</h3>
                    <p class="mb-0">Objects for hosting, memory, and grace</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="collection_box">
                    <img class="img-fluid mb-2 mb-md-4" src="{{asset('public/images/front/bespoke5.png')}}" alt="images">
                    <h3 class="sub_head">For Her — The Desert Rose</h3>
                    <p class="mb-0">Objects for hosting, memory, and grace</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="mt_80">
    <div class="container">
        <div class="row gy-2 gy-md-0">
            <div class="col-md-6">
                <div class="collection_box">
                    <img class="img-fluid  mb-2 mb-md-4" src="{{asset('public/images/front/bespoke4.png')}}" alt="images">
                    <h3 class="sub_head">For Her — The Desert Rose</h3>
                    <p class="mb-0">Objects for hosting, memory, and grace</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="collection_box">
                    <img class="img-fluid  mb-2 mb-md-4" src="{{asset('public/images/front/bespoke5.png')}}" alt="images">
                    <h3 class="sub_head">For Her — The Desert Rose</h3>
                    <p class="mb-0">Objects for hosting, memory, and grace</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="cta_footer mt_120">
    <div class="container">
        <div class="cta_ftwrapper">
            <div>
                <p class="sub_head mb-0">
                    <span>
                        <svg width="146" height="11" viewBox="0 0 146 11" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M10.6666 5.33325C10.6666 8.27877 8.27877 10.6666 5.33325 10.6666C2.38773 10.6666 -8.13802e-05 8.27877 -8.13802e-05 5.33325C-8.13802e-05 2.38773 2.38773 -8.13802e-05 5.33325 -8.13802e-05C8.27877 -8.13802e-05 10.6666 2.38773 10.6666 5.33325ZM145.333 5.33325V6.33325L5.33325 6.33325V5.33325V4.33325L145.333 4.33325V5.33325Z"
                                fill="url(#paint0_linear_32_115)" />
                            <defs>
                                <linearGradient id="paint0_linear_32_115" x1="145.333" y1="5.83325" x2="5.33325"
                                    y2="5.83325" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F8F7F3" stop-opacity="0" />
                                    <stop offset="1" stop-color="#F8F7F3" />
                                </linearGradient>
                            </defs>
                        </svg>

                    </span>
                    <span>Your Union. Your Narrative.</span>
                    <span>
                        <svg width="146" height="11" viewBox="0 0 146 11" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M134.667 5.33325C134.667 8.27877 137.054 10.6666 140 10.6666C142.946 10.6666 145.333 8.27877 145.333 5.33325C145.333 2.38773 142.946 -8.13802e-05 140 -8.13802e-05C137.054 -8.13802e-05 134.667 2.38773 134.667 5.33325ZM0 5.33325L0 6.33325L140 6.33325V5.33325V4.33325L0 4.33325L0 5.33325Z"
                                fill="url(#paint0_linear_32_114)" />
                            <defs>
                                <linearGradient id="paint0_linear_32_114" x1="0" y1="5.83325" x2="140" y2="5.83325"
                                    gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F8F7F3" stop-opacity="0" />
                                    <stop offset="1" stop-color="#F8F7F3" />
                                </linearGradient>
                            </defs>
                        </svg>
                    </span>
                </p>
            </div>

            <div>
                <a href="javascript:void(0)" class="btn_2">Discuss a custom hamper brief with the H Noww team</a>
            </div>
        </div>
    </div>
</section>
@include('layouts.frontfooter')