@extends('admin.layouts.app')

@section('content')
<h2 class="text-center">user page</h2>
@endsection